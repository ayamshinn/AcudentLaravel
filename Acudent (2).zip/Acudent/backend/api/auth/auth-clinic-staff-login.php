<?php
     header("Content-Type: application/json");
     session_start();

     $dbPath = $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';
     if (!file_exists($dbPath)) {
         echo json_encode(["success" => false, "message" => "Server error: DB connection missing."]);
         exit;
     }

     require_once $dbPath;  // Include the DB connection

     if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
         echo json_encode(['success' => false, 'message' => 'Invalid request']);
         exit;
     }

     $input = json_decode(file_get_contents('php://input'), true);
     $username = trim($input['username'] ?? '');
     $password = trim($input['password'] ?? '');

     if (empty($username) || empty($password)) {
         echo json_encode(['success' => false, 'message' => 'Username and password are required']);
         exit;
     }

     // Secure query with prepared statement
     $query = "SELECT user_id, username, password_hash, role_id FROM Users_tb WHERE username = ? LIMIT 1";
     $stmt = $conn->prepare($query);
     $stmt->bind_param("s", $username);
     $stmt->execute();
     $result = $stmt->get_result();

     if ($result->num_rows !== 1) {
         echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
         exit;
     }

     $user = $result->fetch_assoc();

     // Password verification
     if (!password_verify($password, $user['password_hash'])) {
         echo json_encode(['success' => false, 'message' => 'Invalid login credentials']);
         exit;
     }

     // Create session
     $_SESSION['user_id'] = $user['user_id'];
     $_SESSION['username'] = $user['username'];
     $_SESSION['role_id'] = $user['role_id'];

     // NEW: Generate and store API token
     $token = bin2hex(random_bytes(32));  // Secure random token (64 chars)
     $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));  // 1-hour expiry; adjust as needed

     // NEW: Capture IP address and user-agent for logging/security
     $ipAddress = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';  // Fallback if not set
     $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';  // Fallback if not set

     // UPDATED: Insert with additional fields (assuming table has user_agent and ip_address columns)
     $insertQuery = "INSERT INTO api_tokens (user_id, token, expires_at, ip_address, user_agent) VALUES (?, ?, ?, ?, ?)";
     $tokenStmt = $conn->prepare($insertQuery);
     if ($tokenStmt) {
         $tokenStmt->bind_param("issss", $user['user_id'], $token, $expiresAt, $ipAddress, $userAgent);
         if (!$tokenStmt->execute()) {
             // Log error but don't fail login (optional: make it fail if token insert is critical)
             error_log("Token insert failed for user {$user['user_id']}: " . $tokenStmt->error);
             // For now, proceed without token; you could return an error instead
         }
     } else {
         error_log("Token prepare failed: " . $conn->error);    
     }

     // Determine redirect based on role_id
     $redirect = "../user-interface/index.php";  // Default fallback
     switch ($user['role_id']) {
         case 1: $redirect = "../admin-ui/admin-main.php"; break;
         case 2: $redirect = "../dentist-ui/dentist-main.php"; break;
         case 3: $redirect = "../frontdesk-ui/frontdesk-main.php"; break;
         case 4: $redirect = "../assistant-ui/assistant-main.php"; break;
         case 5: $redirect = "../patient-ui/patient-dashboard.php"; break;
     }

     // UPDATED: Include token in response
     echo json_encode(['success' => true, 'redirect' => $redirect, 'token' => $token]);
     exit;
     ?>
     