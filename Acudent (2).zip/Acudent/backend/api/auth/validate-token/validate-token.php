<?php
// Include DB connection
require_once $_SERVER['DOCUMENT_ROOT'] . '/Acudent/backend/config/connection-db.php';

function validateToken() {
    global $conn;  // FIX: Declare $conn as global to access it inside the function

    $headers = getallheaders();
    $authHeader = $headers['Authorization'] ?? '';

    if (!preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
        return false; // No valid Bearer token
    }

    $token = $matches[1];

    // Query token from DB, check expiry, IP, user-agent
    $query = "SELECT user_id, expires_at, ip_address, user_agent FROM api_tokens WHERE token = ? AND expires_at > NOW() LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows !== 1) {
        return false;
    }

    $tokenData = $result->fetch_assoc();
    // Optional: Check IP/user-agent for extra security
    if ($_SERVER['REMOTE_ADDR'] !== $tokenData['ip_address'] || $_SERVER['HTTP_USER_AGENT'] !== $tokenData['user_agent']) {
        return false;
    }

    return $tokenData['user_id']; // Return user_id if valid
}
?>