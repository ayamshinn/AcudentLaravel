<?php
// Database connection settings
$host = "localhost";
$user = "root";
$pass = "";  // Leave empty for default XAMPP
$db_name = "acudent_db";

// Create connection
$conn = mysqli_connect($host, $user, $pass, $db_name);

// Check connection
if (!$conn) {
    // Log the error for debugging (don't expose in production)
    error_log("Database connection failed: " . mysqli_connect_error());
    
    // Return JSON error response
    http_response_code(500);
    header("Content-Type: application/json");
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed. Please try again later."
    ]);
    exit;
}

// Optional: Set charset to avoid encoding issues
mysqli_set_charset($conn, "utf8");
?>