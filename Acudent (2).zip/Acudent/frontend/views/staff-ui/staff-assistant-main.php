<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    
    <link rel="stylesheet" href="../../assets/css/shared-ui/shared.css">
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-dashboard.css">
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-patient-records.css">
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-patient-records-detailed.css">

    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-appointments.css">
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-help.css">
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-inventory-management.css">
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-messages.css">   
    <link rel="stylesheet" href="../../assets/css/staff-ui/staff-assistant-backup-css/staff-assistant-my-account.css">



    <!-- FullCalendar CSS & JS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>

    <link href='https://cdn.boxicons.com/fonts/basic/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap');
    </style>
    <title>Staff Portal</title>
</head>

<body>
    <!-- ============================Main Container============================ -->
    <div class="main-container container-fluid d-flex px-0">

        <!-- ============================Sidebar Container============================ -->

        <aside class="sidebar-container" id="sidebar-container">
            <!-- Logo -->
            <div class="sidebar-top-logo mx-3">
                <div class="toggle-sidebar">
                    <i class="fa-solid fa-bars"></i>
                </div>
                <img src="../../assets/images/user-interface/banners-images-logo/logo.png" alt="Clinic Logo"
                    class="logo-img">
                <div class="logo-text ms-2">
                    <h3 class="mb-0">Mapru</h3>
                    <h5 class="mb-0">Dental Clinic</h5>
                </div>
            </div>

            <div class="sidebar-content ps-2 pt-2">

                <!-- User Profile -->
                <div class="sidebar-user-profile-picture">
                    <div class="sidebar-profile-info-container">
                        <div class="sidebar-userprofile-img">
                            <img src="" alt="User Profile">
                        </div>
                        <div class="sidebar-userprofile-name-container">
                            <h3 id="sidebar-profileName">Mikee De Leon</h3>
                            <p> <span id="sidebar-patient-id">@mikee_deleon</span></p>
                        </div>

                    </div>

                    <a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-my-account.html" class="btn-my-account" 
                    data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-my-account.html"
                        data-bs-toggle="tooltip" data-bs-placement="right" title="Dashboard"><i class="fas fa-user"></i>
                        <span>My Account</span></a>
                </div>
                <!-- ============================ Navigation ============================ -->
                <nav class="sidebar-navigation w-100">
                    <ul class="sidebar-nav-list">

                        <!-- ========== Navigation Section ========== -->
                        <li class="sidebar-section-title">Navigation</li>
                        <li><a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-dashboard.html" class="btn-sidebar d-flex align-items-center"
                                data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-dashboard.html" data-bs-toggle="tooltip"
                                data-bs-placement="right" title="Dashboard">
                                <i class="fa-solid fa-table-columns"></i><span>Dashboard</span></a>

                        </li>
                        <li><a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-patient-records.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-patient-records.html">
                                <i class="fas fa-book"></i> <span>Patient Records</span></a>
                        </li>

                        <li><a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-appointments.html"
                                class="btn-sidebar d-flex align-items-center"
                                data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-appointments.html">
                                <i class="fas fa-calendar"></i> <span>Appointments</span></a>
                        </li>
                        <li><a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-messages.html"
                            class="btn-sidebar d-flex align-items-center"
                            data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-messages.html">
                            <i class="fa-solid fa-message"></i><span>Messages</span></a>
                    </li>

                        <li><a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-inventory-management.html"
                                 class="btn-sidebar d-flex align-items-center" data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-inventory-management.html"
                                data-bs-toggle="tooltip" data-bs-placement="right" title="My Record">
                                <i class="fa-solid fa-clipboard"></i><span>Inventory</span></a>
                        </li>
                        
              

                        <!-- ========== Components Section ========== -->
                        <li class="sidebar-section-title">Component</li>
                        <li><a href="../staff-ui/staff-assistant-main.html#../staff-ui/staff-assistant-subfolder/staff-assistant-help.html" 
                            class="btn-sidebar d-flex align-items-center" data-page="../staff-ui/staff-assistant-subfolder/staff-assistant-help.html" >
                                <i class="fa-solid fa-circle-question"></i> <span>Help</span></a></li>
                        
                    </ul>
                </nav>
                <!-- Logout -->
                <div class="sidebar-logout pe-2">
                    <a href="../user-interface/index.html" class="btn-sidebar sidebar-logout-btn d-flex align-items-center" id="logoutBtn">
                        <i class="fa-solid fa-right-from-bracket"></i> <span>Logout</span>
                    </a>
                </div>

            </div>
        </aside>

        <script src="../../assets/js/shared-ui/shared.js"></script>

        <!-- ============================Content Area Container============================ -->

        <main class="main-content-area-container" id="main-content-area-container">
            <!-- ==============================Tobar============================= -->
            <div class="topbar" id="topbar">
                <div class="topbar-left">
                    <div class="toggle">
                        <i class="fa-solid fa-bars"></i>
                    </div>
                    <h3>Today's Date:</h3>
                    <div class="today-date" id="today-date">

                    </div>
                </div>

                <div class="contentarea-topbar-profile">
                    <div class="notification">
                        <a href="" class="icon-wrapper me-3 position-relative" data-page="Messages" title="Messages">
                            <i class="fa-solid fa-envelope"></i>
                            <span class="badge message-badge">1</span>
                        </a>

                        <a href="" class="icon-wrapper icon-bell-notif me-5 position-relative" data-page="Notification"
                            title="Notifications">
                            <i class="fas fa-bell"></i>
                            <span class="badge system-notif-badge">1</span>
                        </a>

                    </div>
                    <h4 class="topbar-profile-name" id="topbar-profilename">Malibu, Dracy</h4>
                    <div class="contentarea-topbar-user">
                        <img src="assets/imgs/customer01.jpg" alt="">
                    </div>
                </div>

            </div>

            <div class="content-container d-flex flex-column">
                <div class="content-area  flex-grow-1" id="content-area"></div>

                <footer class="footer w-100 d-flex justify-content-end align-items-center p-3">
                    <div class="footer-inner w-100 d-flex justify-content-end align-items-center">
                        <p class="m-0">&copy; 2025 Mapru</p>
                    </div>
                </footer>
            </div>
          <script src="../../assets/js/staff-ui/staff-assistant-main.js"></script>
        </main>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>


</body>

</html