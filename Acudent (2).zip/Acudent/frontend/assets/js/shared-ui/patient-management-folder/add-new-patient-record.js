<div class="patient-information-record-main">
    <div class="head d-flex align-items-center">

        <h1 class="pt-2">Patient Information Record</h1>

        <div class="head-btn-container d-flex gap-2">
            <button class="head-btn">Edit</button>
            <button class="head-btn">Export Copy</button>
        </div>

    </div>


    <div class="patient-information-container container-fluid">

        <h6>Patient Information Record</h6>
        <hr class="hr1">
        <div class="patient-profile-container container-fluid ">
            <div class="patient-profile-overview d-flex py-3">
                <div class="patient-information-profile d-flex align-items-center gap-2">

                    <div class="patient-information-profile-img">
                        <img src="" alt="">
                    </div>
                    <div class="patient-information-profile-text align-items-center">


                        <h1>Patient ID: <span class="patient-information-profile-id">M-23234</span></h1>
                        <h4 class="patient-information-profile-name">Dracy malibu</h4>

                    </div>
                </div>
            </div>
        </div>
        <hr class="hr1 mt-0 mb-4">

        <!-- ==============Personal Details================= -->

        <div class="patient-information-personal-details-container">

            <div class="patient-information-header px-4 mb-4">
                <h2>Personal Details</h2>
                <hr>
            </div>
            <div
                class="row patient-information-section-row row-cols-xl-3 row-cols-lg-3 row-cols-md-2 row-cols-sm-2 row-cols-1 m-0 gx-5">
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="LastName" class="form-control" placeholder="Last Name" name="LastName"
                            required>
                        <label for="LastName">Last Name<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="FirstName" class="form-control" placeholder="First Name" name="FirstName"
                            required>
                        <label for="FirstName">First Name<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="MiddleInitial" class="form-control" placeholder="Middle Initial"
                            name="MiddleInitial" maxlength="1">
                        <label for="MiddleInitial">Middle Initial</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <select id="Gender" name="Gender" class="form-control" name="Gender" required>
                            <option value="" disabled selected>Select Gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                        <label for="Gender">Gender<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="date" id="Birthdate" class="form-control" name="Birthdate" required>
                        <label for="Birthdate">Birthdate<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="Age" class="form-control" placeholder="Age" name="Age" required>
                        <label for="Age">Age<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="Nationality" class="form-control" placeholder="Nationality"
                            name="Nationality">
                        <label for="Nationality">Nationality</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="tel" id="PhoneNumber" class="form-control" placeholder="Phone Number"
                            name="PhoneNumber" required>
                        <label for="PhoneNumber">Phone Number<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record col-12 col col-md-12 col-sm-12">
                    <div class="form-floating">
                        <input type="email" id="Email" class="form-control" placeholder="Email" name="Email" required>
                        <label for="Email">Email<span class="required">*</span></label>
                    </div>
                </div>
                <div class="col personal-information-record col-12 col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="form-floating">
                        <input type="text" id="Address" class="form-control" placeholder="Address" name="Address"
                            required>
                        <label for="Address">Address<span class="required">*</span></label>
                    </div>
                </div>
            </div>
        </div>

        <!-- ======================Medical History========================= -->

        <div class="patient-information-medical-history-container">
            <div class="patient-information-header px-4 mb-4">
                <h2>Medical History</h2>
                <hr>
            </div>
            <div
                class="row patient-information-section-row medical-history-row row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1 m-0 gx-5">

                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="CurrentMedications" class="form-control"
                            placeholder="Current Medications" name="CurrentMedications">
                        <label for="CurrentMedications">Current Medications</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="PastSurgeries" class="form-control"
                            placeholder="Past Surgeries/Hospitalizations" name="PastSurgeries">
                        <label for="PastSurgeries">Past Hospitalizations</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="Allergies" class="form-control" placeholder="Allergies" name="Allergies">
                        <label for="Allergies">Allergies</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="Menstruation" class="form-control" placeholder="Menstruation"
                            name="Menstruation">
                        <label for="Menstruation">Menstruation</label>
                    </div>
                </div>
                <div class="col personal-information-record col-12 col-lg-12 col-md-12 ">
                    <div class="form-floating mb-3">
                        <input type="text" id="MedicalConditions" class="form-control" placeholder="Medical Conditions"
                            name="MedicalConditions">
                        <label for="MedicalConditions">Medical Conditions</label>
                    </div>
                </div>

            </div>
        </div>
        <!-- ====================HMO Information======================== -->
        <div class="patient-information-hmo-information-container">
            <div class="patient-information-header px-4 mb-3">
                <h2>HMO Information</h2>
                <hr>
            </div>
            <div class="row patient-information-section-row hmo-information-row row-cols-1 g-5">

                <div class="col personal-information-record-hmo mx-4">
                    <div class="form-group mb-3">
                        <p>Are you covered by an HMO?</p>
                        <div class="form-check">
                            <input type="radio" class="form-check-input" name="hasHMO" value="yes"> Yes
                        </div>
                        <div class="form-check">
                            <input type="radio" class="form-check-input" name="hasHMO" value="no"> No
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="patient-information-hmo-information-container">
            <div class="patient-information-header-hmo px-2 mb-3">
                <h2>If yes, fill out the following:</h2>
            </div>
            <div
                class="row patient-information-section-row hmo-information-row row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1 m-0 gx-5">
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="HMOProvider" class="form-control" placeholder="HMO Provider"
                            name="HMOProvider">
                        <label for="HMOProvider">HMO Provider</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="MembershipID" class="form-control" placeholder="Membership ID No."
                            name="MembershipID">
                        <label for="MembershipID">Membership ID No.</label>
                    </div>
                </div>
            </div>
        </div>



        <div class="patient-information-minor-patient-container">

            <div class="patient-information-header px-4 mb-3">
                <h2>For Patient Under 18 Years Old</h2>
                <hr>
            </div>

            <div
                class="row patient-information-section-row insurance-information-row row-cols-lg-2 row-cols-md-2 row-cols-sm-1 row-cols-1 m-0 gx-5">

                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="guardian-fullname" class="form-control"
                            placeholder="Guardian's Full Name" name="guardian-fullname">
                        <label for="guardian-fullname">Guardian's Full Name</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="tel" id="MContactNum" class="form-control" placeholder="Contact Number"
                            name="MContactNum">
                        <label for="MContactNum">Contact Number</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="text" id="RltoPatient" class="form-control"
                            placeholder="Relationship to the patient" name="RltoPatient">
                        <label for="RltoPatient">Relationship to the patient</label>
                    </div>
                </div>
                <div class="col personal-information-record">
                    <div class="form-floating">
                        <input type="email" id="GuardianEmail" class="form-control" placeholder="Email"
                            name="GuardianEmail">
                        <label for="GuardianEmail">Email</label>
                    </div>
                </div>

            </div>
        </div>


        <div class="patient-information-consent-agreement-container">

            <div class="patient-information-header px-4 mb-3">
                <h2>Consent and Agreement</h2>
                <hr>
            </div>


            <div class="patient-consent-statement">
                <a href="">
                    <h3 class="font-medium text-gray-800 mb-3">Patient Consent Statement</h3>
                </a>
                <p class="text-sm text-gray-600 leading-relaxed mb-4">
                    I hereby consent to the collection, use, and disclosure of my personal health information by this
                    healthcare facility for the purposes of providing medical care, treatment, and related healthcare
                    services. I understand that my information will be kept confidential and used only for legitimate
                    medical purposes in accordance with applicable privacy laws and regulations.
                </p>
                <p class="text-sm text-gray-600 leading-relaxed">
                    I acknowledge that I have read and understood the privacy policy and terms of service. I confirm
                    that all information provided in this form is accurate and complete to the best of my knowledge.
                </p>
            </div>

            <label class="patient-consent-statement">
                <input type="checkbox" required class="mt-1 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                <span>
                    I have read, understood, and agree to the above consent statement and terms. I confirm that all
                    information provided is accurate and complete. *
                </span>
            </label>

        </div>

        <div class="patient-information-btn-container container-fluid">

            <button class="patient-information-btn btn-save">Save</button>
            <button class="patient-information-btn btn-cancel">Cancel</button>
        </div>
    </div>


</div>
