document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("adminLoginForm");
    if (!loginForm) return;  // Only run login logic if the form exists (i.e., on the login page)

    loginForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const username = document.getElementById("admin-user").value.trim();
        const password = document.getElementById("admin-pass").value.trim();
        const errorMsg = document.querySelector(".error-msg");

        if (!username || !password) {
            if (errorMsg) errorMsg.textContent = "Please enter username and password.";
            return;
        }

        try {
            const response = await fetch("/Acudent/backend/api/auth/auth-clinic-staff-login.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username, password })
            });

            const result = await response.json();

            if (!result.success) {
                if (errorMsg) errorMsg.textContent = result.message || "Invalid login.";
                return;
            }

            // Store token for future requests
            if (result.token) {
                localStorage.setItem('authToken', result.token);  // Persist across sessions; use sessionStorage for tab-only
            }

            // Redirect from server response
            window.location.href = result.redirect;

        } catch (err) {
            console.error(err);
            if (errorMsg) errorMsg.textContent = "Error connecting to server.";
        }
    });

    // Global function for authenticated API calls (can be used in other JS files)
    window.makeAuthenticatedRequest = async function(url, options = {}) {
        const token = localStorage.getItem('authToken');
        if (!token) {
            console.error('No token found. Please log in.');
            return;
        }

        const headers = { ...options.headers, 'Authorization': `Bearer ${token}` };
        return fetch(url, { ...options, headers });
    };
});
